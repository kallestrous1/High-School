import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;

public class Human implements Comparable <Human>{
	
	static final Comparator <Human> AGE_ORDER = new Comparator <Human>() {
		public int compare (Human human, Human humanOpponent) {
			return human.compareTo(humanOpponent);
		}
	};	

	static final Comparator <Human> NAME_ORDER= new Comparator <Human>() {
		public int compare (Human human, Human humanOpponent) {
			return human.compareName(humanOpponent);
		}
	};	
	static final Comparator <Human> ASSEMBLY_ORDER= new Comparator <Human>() {
		public int compare (Human human, Human humanOpponent) {
			return human.compareOrder(humanOpponent);
		}
	};
		
	private int birthYear;
	private int birthMonth;
	private int birthDay;
		
	String firstName;
	String lastName;
	
	Gender gender; 
	static int ASSEMBLYRANK=0;
	int assemblyRank;
	
	public Human(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender) {
		this.birthYear=birthYear;
		this.birthMonth=birthMonth;
		this.birthDay=birthDay;
		
		this.firstName=firstName;
		this.lastName= lastName;
		this.assemblyRank=ASSEMBLYRANK;
		this.gender = gender; 
		
			}
	
	public int getBirthYear() {
		return birthYear;
	}
	
	public int getBirthMonth() {
		return birthMonth;
	}
	
	public int getBirthDay() {
		return birthDay;
	}
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	

	
	public void setBirthYear(int birthYear) {
		this.birthYear= birthYear;
	}
	
	public void setBirthMonth(int birthMonth) {
		this.birthMonth= birthMonth;
	}
	
	public void setBirthDay(int birthDay) {
		this.birthDay= birthDay;
	}
	
	public void setFirstName(String firstName) {
		this.firstName = firstName; 		
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName; 		
	}
		
	int calculateCurrentAgeInYears() {
		LocalDate dateOfBirth= LocalDate.of(birthYear, birthMonth, birthDay);
		LocalDate now = LocalDate.now();
		long years = ChronoUnit.YEARS.between(dateOfBirth, now);
		return (int)years;

	}
	
	int calculateCurrentAgeInDays() {
		LocalDate dateOfBirth= LocalDate.of(birthYear, birthMonth, birthDay);
		LocalDate now = LocalDate.now();
		long years = ChronoUnit.DAYS.between(dateOfBirth, now);
		return (int)years;

	}
	@Override
	public int compareTo(Human o) {
		int difference =o.calculateCurrentAgeInDays()-calculateCurrentAgeInDays();				
		return difference;
	}
	
	public int compareName(Human o) {
		return (lastName+firstName).compareTo(o.getLastName()+o.getFirstName());
	}
	
	public int compareOrder(Human o) {
		System.out.println(getAssemblyRank());
		if (getAssemblyRank()>o.getAssemblyRank()) {
			return -1;
		}
		else if(o.getAssemblyRank()>getAssemblyRank()) {
			return 1;
		}
		else {
			return (lastName+firstName).compareTo(o.getLastName()+o.getFirstName());
		}
		
	}
	
	public Gender getGender() {
		return gender;
	}
	
	public int getAssemblyRank() {
		return assemblyRank;
	}

	
}