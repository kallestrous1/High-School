
public class Introducer{
	
	String pronouns = "";
	String fullName = "";
	String job = "";
	String schooling = "";
	String homeroom = "";
	int age = 100;
	Gender gender;
		
	public String getPronouns(Human person) {
		gender = person.getGender();
		pronouns = gender.toString();	
		if(pronouns == "FEMALE") {
			return "She";
		} else if (pronouns == "MALE") {
			return "He";
		} else {
			return "They";
		}
	}

	public String createPublicIntroduction(Human person) {		
	
		
		try {
			fullName = person.getFirstName() + " " + person.getLastName() + ".";
			
			if (person instanceof Adult) {
				Adult grownUp=(Adult)person;
				job = String.format( " %s works at %s and their occupation is %s.", getPronouns(grownUp), grownUp.getPlaceOfWork(), grownUp.getOccupation() );
			} 
			else {
				job="";
			}
				
			if (person instanceof Youth) {
				Youth kid=(Youth)person;
				schooling = String.format(" %s goes to %s and is in grade %s.", getPronouns(kid), kid.getSchoolName(), kid.getSchoolGrade()); 
			}
			
			if (person instanceof WilliamAberhartStudent) {
				WilliamAberhartStudent abeKid = (WilliamAberhartStudent)person; 
				homeroom = abeKid.getHomeRoomTeacher();
				if (homeroom != null) {
					homeroom = String.format(" %s belongs to %s's homeroom, which is in room %d.", getPronouns(abeKid),abeKid.getHomeRoomTeacher(), abeKid.getHomeRoom());
				} else {
					homeroom = " Their homeroom is unknown at this time.";
				}
			} 
			
		} catch (ArrayIndexOutOfBoundsException e) {
			return "This person has issues and can't be introduced.";
		}
		try {
			age = person.calculateCurrentAgeInYears();
		} catch (ArithmeticException a) {
			return "This person has issues and can't be introduced.";
		}
		
		return "I am pleased to introduce " + fullName + job + schooling + homeroom;
		
	}
}
