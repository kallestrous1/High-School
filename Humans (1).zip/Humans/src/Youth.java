
public class Youth extends Human{
	
	int schoolGrade;
	String schoolName;
	static int ASSEMBLYRANK=2;
	int assemblyRank;

	
	public Youth(int birthYear, int birthMonth, int birthDay, String firstName, String lastName, Gender gender, int schoolGrade, String schoolName) {
		super(birthYear, birthMonth, birthDay, firstName, lastName, gender);
		
		this.schoolGrade = schoolGrade;
		this.schoolName = schoolName;
		this.assemblyRank=ASSEMBLYRANK;

	}
	
	public int getSchoolgrade() {
		return schoolGrade;
	}
	
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolgrade(int schoolgrade) {
		this.schoolGrade=schoolgrade;
	}
	public void setschoolName(String schoolName) {
		this.schoolName=schoolName;
	}

	public int getSchoolGrade() {
		return schoolGrade;
	}
	public int getAssemblyRank() {
		return assemblyRank;
	}

}
